Joey Chan - Jchan58
- Worked on finding Objectfile, instruction set, Endianness, finding section information, and printing section information, symbol table, symbol table printing

Sola Oladosu
-Worked on file preparation (ensuring opening, getting file size, mmap, and that it is an ELF file), symbol table reading and information printing
