--Sola Oladosu
worked on hex_format_offset, hex_format_byte_as_hex, hex_to_printable, main

--Ji Chan
hex_read, hex_write, hex_to_printable, MS1 asm functions

