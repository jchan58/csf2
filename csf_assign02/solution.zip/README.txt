--Sola Oladosu
worked on c hex_format_offset, c hex_format_byte_as_hex, c hex_to_printable, all of assembly

--Ji Chan
c hex_read, c hex_write, c hex_to_printable, all of assembly

