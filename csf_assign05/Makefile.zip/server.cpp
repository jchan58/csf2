#include <pthread.h>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <algorithm>
#include <memory>
#include <set>
#include <vector>
#include <cctype>
#include <cassert>
#include "message.h"
#include "connection.h"
#include "user.h"
#include "room.h"
#include "guard.h"
#include "server.h"
#include <map>
#include <iterator>

using std::map;
using std::iterator;


////////////////////////////////////////////////////////////////////////
// Server implementation data types
////////////////////////////////////////////////////////////////////////

// TODO: add any additional data types that might be helpful
//       for implementing the Server member functions

//hold info about the connection object (from lecture 30, slide 24)
typedef struct ConnInfo {
  Connection *conn;
  Server *server;

  ConnInfo(Connection *conn, Server *server) : conn(conn), server(server) { }
  ~ConnInfo() {
    // destroy connection when ConnInfo object is destroyed
    delete conn;
  }

} ConnInfo;


////////////////////////////////////////////////////////////////////////
// Client thread functions
////////////////////////////////////////////////////////////////////////


Room *Server::find_or_create_room(const std::string &room_name) {
  // TODO: return a pointer to the unique Room object representing
  //       the named chat room, creating a new one if necessary
  //first find if the room exists already - if not create a room
  //create an iterator to iterate over the map


  // this function can be called from multiple threads, so
  // make sure the mutex is held while accessing the shared
  // data (the map of room names to room objects)
  Guard g(m_lock);

  Room *room;

  auto i = m_rooms.find(room_name);
  if (i == m_rooms.end()) {
    // room does not exist yet, so create it and add it to the map
    room = new Room(room_name);
    m_rooms[room_name] = room;
  } else {
    room = i->second;
  }

  return room;
  
}



void chat_with_sender(Connection *conn, std::string username, ConnInfo* info){
  User* user = new User(username); 
  user->username = username;
  user->sender = true;
  
  while(true){
    Message received = Message();
    conn->receive(received);
    if(strcmp(received.tag.c_str(), "join") == 0 && user->room == NULL){
      Room* room = info->server->find_or_create_room(received.data);
     //have the user join the room
     room->add_member(user);
     user->room = room; 
     Message ok = Message("ok", username);
     conn->send(ok);
     //broadcast the message to all the queues
   } else if(strcmp(received.tag.c_str(), "sendall") == 0 && user->room != NULL){
      user->room->broadcast_message(username, received.data.c_str());
   } else if(strcmp(received.tag.c_str(), "leave") == 0 && user->room != NULL){
     user->room->remove_member(user);
     user->room = NULL;  
     Message ok = Message("ok", "");
     conn->send(ok);
     //in order to quit must leave the room first 
   } else if(strcmp(received.tag.c_str(), "quit") == 0){
     user->room->remove_member(user);
     user->room = NULL;
     Message ok = Message("ok", "");
     conn->send(ok);
     return; 
   }
  }
 }


void chat_with_receiver(Connection *conn,  std::string& username, std::string &room_name, ConnInfo* info){
  User* user = new User(username);
  //find room/create one if it does not exists
  Room* room = info->server->find_or_create_room(room_name);
  //join room
  room->add_member(user);
  //now user is in room

  Message ok = Message("ok", username);
  conn->send(ok);

  
  //deliver messages
    while(true){
      Message* msg = room->take_message();
      //Message& msg_ref = msg;
      bool sent = conn->send(*msg);
      if(sent){
	 Message ok = Message("ok", username);
	 conn->send(ok);
      } else {
	 Message error = Message("err", "error");
	 conn->send(error);
      }
      delete(msg);
    }
}
 

namespace {

void *worker(void *arg) {
  pthread_detach(pthread_self());
  //use a static cast to convert arg from a void* to
  //       whatever pointer type describes the object(s) needed
  //       to communicate with a client (sender or receiver)
  ConnInfo *info_ = static_cast<ConnInfo *>(arg);

  // use a std::unique_ptr to automatically destroy the ConnInfo object
  // when the worker function finishes; this will automatically ensure
  // that the Connection object is destroyed
  std::unique_ptr<ConnInfo> info(info_);


Message msg;

  if (!info->conn->receive(msg)) {
    if (info->conn->get_last_result() == Connection::INVALID_MSG) {
      info->conn->send(Message(TAG_ERR, "invalid message"));
    }
    return nullptr;
  }

  if (msg.tag != TAG_SLOGIN && msg.tag != TAG_RLOGIN) {
    info->conn->send(Message(TAG_ERR, "first message should be slogin or rlogin"));
    return nullptr;
  }

  std::string username = msg.data;
  if (!info->conn->send(Message(TAG_OK, "welcome " + username))) {
    return nullptr;
  }

  // Just loop reading messages and sending an ok response for each one
  while (true) {
    if (!info->conn->receive(msg)) {
      if (info->conn->get_last_result() == Connection::INVALID_MSG) {
        info->conn->send(Message(TAG_ERR, "invalid message"));
      }
      break;
    }

    if (!info->conn->send(Message(TAG_OK, "this is just a dummy response"))) {
      break;
    }
  }

  return nullptr;

 }
}
////////////////////////////////////////////////////////////////////////
// Server member function implementation
////////////////////////////////////////////////////////////////////////

Server::Server(int port)
  : m_port(port)
  , m_ssock(-1) {
  //initialize mutex
  //what is the other parameter?
  pthread_mutex_init(&m_lock, NULL);
}

Server::~Server() {
  //destroy mutex
  pthread_mutex_destroy(&m_lock);
}


bool Server::listen() { 
  std::string port = std::to_string(m_port);
  m_ssock = open_listenfd(port.c_str());
  return m_ssock >= 0;  
 
}

//from lecture 30, slide 26 ???
void Server::handle_client_requests() {
  //infinite loop calling accept or Accept, starting a new
  //       pthread for each connected client

  assert(m_ssock >= 0);
  while(true){
   int clientfd = Accept(m_ssock, nullptr, nullptr);
   if (clientfd < 0) {
     std::cerr << "Error accepting client connection" << std::endl;
     return;
   } 

   ConnInfo *info = new ConnInfo(new Connection(clientfd), this);
   
  
   pthread_t thr_id;

   if(pthread_create(&thr_id, nullptr, worker, static_cast<void *>(info)) != 0) {
     std::cerr << "pthread_create failed" << std::endl;
     return;
   }
  }
}
