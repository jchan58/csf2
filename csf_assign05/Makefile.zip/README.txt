README.txt Milestone 1

Joey Chan

I worked on message.h and sender.cpp. 


Sola Oladosu

I worked on connection.cpp and reciever.cpp
